class Solution
{
public:
    void bfs(int nod, int n, vector<vector<int>>& a, int color[])
    {
        //bfs-ul porneste de la culoarea 1 si pune culoarea 2 la toate nodurile care se afla cu el in dislikes
        int coada[n+1];
        color[nod]=1;
        int inc, sf;
        inc=sf=1;
        coada[inc]=nod;
        while(inc<=sf)
        {
            for(int i=1; i<=n; i++)
            {
                if(color[i]==0 && a[coada[inc]][i]==1)
                {
                    sf++;
                    coada[sf]=i;
                    if(color[coada[inc]]==1)
                        color[i]=2;
                    else
                        color[i]=1;
                }

            }
            inc++;

        }

    }

    bool possibleBipartition(int n, vector<vector<int>>& dislikes)
    {
        vector<vector<int>>a(n+1); //matrice de adiacenta
        for(int i=1; i<=n; i++)
        {
            a[i].resize(n+1);
            for(int j=1; j<=n; j++)
                a[i][j]=0;
        }

        for(int i=0; i<dislikes.size(); i++) //in a marchez cu 1 perechile de noduri care se displac
            a[dislikes[i][0]][dislikes[i][1]]=a[dislikes[i][1]][dislikes[i][0]]=1;
        int color[n+1];
        for(int i=1; i<=n; i++)
            color[i]=0; //pornesc cu toate nodurile ca fiind necolorate

        for(int i=1; i<=n; i++)
            if(color[i]==0) //daca un nod nu e colorat, incep parcurgerea din el
                bfs(i, n, a, color);

        for(int i=1; i<=n; i++)
            for(int j=i+1; j<=n; j++)
                if(color[i]==color[j] && a[i][j]==1) //daca 2 noduri i si j se displac si au aceeasi culoare nu am solutie
                      return false;

            return true;
    }

};

/*
b)
class Solution
{
public:
    void bfs(int nod, int n, vector<vector<int>>& a, int color[])
    {
        //bfs-ul porneste de la culoarea 1 si pune culoarea 2 la toate nodurile care se afla cu el in dislikes
        int coada[n+1];
        color[nod]=1;
        int inc, sf;
        inc=sf=1;
        coada[inc]=nod;
        while(inc<=sf)
        {
            for(int i=1; i<=n; i++)
            {
                if(color[i]==0 && a[coada[inc]][i]==1)
                {
                    sf++;
                    coada[sf]=i;
                    if(color[coada[inc]]==1)
                        color[i]=2;
                    else
                        color[i]=1;
                }

            }
            inc++;

        }

    }

    vector <vector<int>> possibleBipartition(int n, vector<vector<int>>& dislikes)
    {
        vector<vector<int>>a(n+1), rez(2); //matrice de adiacenta
        for(int i=1; i<=n; i++)
        {
            a[i].resize(n+1);
            for(int j=1; j<=n; j++)
                a[i][j]=0;
        }

        for(int i=0; i<dislikes.size(); i++) //in a marchez cu 1 perechile de noduri care se displac
            a[dislikes[i][0]][dislikes[i][1]]=a[dislikes[i][1]][dislikes[i][0]]=1;
        int color[n+1];
        for(int i=1; i<=n; i++)
            color[i]=0; //pornesc cu toate nodurile ca fiind necolorate

        for(int i=1; i<=n; i++)
            if(color[i]==0) //daca un nod nu e colorat, incep parcurgerea din el
                bfs(i, n, a, color);

        for(int i=1; i<=n; i++)
            for(int j=i+1; j<=n; j++)
                if(color[i]==color[j] && a[i][j]==1) //daca 2 noduri i si j se displac si au aceeasi culoare nu am solutie
                      ok=0;

           if(ok==1)
           {
               for(int i=1; i<=n; i++)
                rez[color[i]-1].push_back(i); //in rez[0] pun nodurile colorate cu 1, iar in rez[1] celelalte
           }
           return rez;

    }

};
*/

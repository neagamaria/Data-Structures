#include <iostream>
#include <fstream>
#include <vector>

using namespace std;
/*Idee: fac BFS din toate pct de control si actualizez pt fiecare drumul min de pana la un pct de control
Complexitate: O(n+m) (BFS) */

ifstream in("graf.in");
ofstream out("graf.out");

int n, m, x, y, viz[10001];
int drum[10001]; //in drum tin distanta pana la cel mai apropiat pct de control
vector <int> l[10001];
void bfs(int nod)
{
    drum[nod]=0;
    viz[nod]=1;
    int coada[1000];
    coada[1]=nod;
    int inc, sf;
    inc=sf=1;
    while(inc<=sf)
    {
        for(int i=0; i<l[coada[inc]].size(); i++)
        {
            int vecin=l[coada[inc]][i];
            if(viz[vecin]==0)
            {
                sf++;
                coada[sf]=vecin;
                if(drum[vecin]==-1 || drum[vecin]>drum[coada[inc]]+1)//daca nu exista inca dist pana la un pct de control
                {
                    //sau am gasit un pct de control mai apropiat
                    drum[vecin]=drum[coada[inc]]+1;//actualizez drumul
                    viz[vecin]=1;
                }

            }
        }
        inc++;
    }

}

int main()
{
    in>>n>>m;
    for(int i=1; i<=n; i++)
        drum[i]=-1;
    for(int i=1; i<=m; i++)
    {
        in>>x>>y;
        l[x].push_back(y);
        l[y].push_back(x);
    }

    int cnt=1;

    while(in>>x)
    {
        for(int j=1; j<=n; j++)
            viz[j]=0;
        bfs(x);
    }

    for(int i=1; i<=n; i++)
    {
        out<<drum[i]<<" ";
    }


    return 0;
}

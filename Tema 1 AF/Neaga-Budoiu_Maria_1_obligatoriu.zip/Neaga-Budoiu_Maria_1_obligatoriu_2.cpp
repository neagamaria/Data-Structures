#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int n, m, x, y, drum[100001], viz[100001], poz[100001];
vector <int> l[100001], parcurgere; //parcurgere retine nodurile in ordinea vizitarii lor in dfs

bool aranjare(int i, int j)//fct care ajuta la ordonarea listelor de adiacenta dupa pozitiile nodurilor in drumul dat
{
    if(poz[i]<poz[j])
        return 1;
    return 0;
}

void dfs(int nod, int nr)
{
    viz[nod]=nr;
    parcurgere.push_back(nod);
    for(int i=0; i<l[nod].size(); i++)
    {
        if(viz[l[nod][i]]==0)
            dfs(l[nod][i], nr+1);

    }
}


int main()
{
   cin>>n>>m;
   for(int i=0; i<n; i++)
   {
       cin>>drum[i];
       poz[drum[i]]=i; //pozitia nodului dat este contorul curent
   }

   for(int i=0; i<m; i++)
   {
       cin>>x>>y;
       l[x].push_back(y);
       l[y].push_back(x);
   }

   for(int i=0; i<=n; i++)
   {
       /*
       Pt un nod i, ii mutam vecinii in ordinea in care se gasesc ei in drumul dat
       si putem incerca astfel parcurgerea in acea ordine.
       */
       sort(l[i].begin(), l[i].end(), aranjare);
   }

   dfs(1, 1);

   bool ok=1;

   for(int i=0; i<n; i++)
   {

       if(parcurgere[i]!=drum[i] && l[i].size()>=1) //daca parcurgerea in dfs nu corespunde ordinii din drumul dat si nodul curent nu e izolat (nodurile isolate se parcurg in orice ordine)
       {
           ok=0;
           break;
       }
   }
   cout<<ok;

    return 0;
}

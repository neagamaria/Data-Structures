class Solution {
public:
    stack <int> st; //in st vom adauga cursurile dupa ce au fost parcurse toate cursurile de dupa ele
    bool ok=1; //marcheaza daca putem construi solutie

    void dfs(int nod, vector<int> &viz, vector<int> l[])
    {
        if(ok==1)
        {
            viz[nod]=-1; //marcam cu -1 cand incepem parcurgerea de la cursul 'nod'
            for(int i=0; i<l[nod].size(); i++)
            {
                if(viz[l[nod][i]]==0)
                    dfs(l[nod][i],viz, l);
                if(viz[l[nod][i]]==-1) //daca cursul apartine deja parcurgerii, atunci a fost facut inainte de cursul 'nod' => contradictie
                    ok=0;
            }
            st.push(nod); //punem cursul in stiva dupa terminarea dfs-ului pt el
            viz[nod]=1; //marcam cu 1 cand am terminat parcurgerea ce incepe cu cursul 'nod'
        }

    }


    vector <int> findOrder(int numCourses, vector<vector<int>>& prerequisites)
    {
        vector<int> l[numCourses+2], viz(numCourses+2), sol;
        for(int i=0; i<numCourses; i++)
            viz[i]=0;
        for(int i=0; i<prerequisites.size(); i++)
            l[prerequisites[i][1]].push_back(prerequisites[i][0]); //creare liste adiacenta

        for(int i=0;i<numCourses;i++)
        {
            if(viz[i]==0)
                dfs(i, viz, l);
        }

        if(ok==1)
        {
            while(st.empty()==false)
            {
                sol.push_back(st.top());
                st.pop();
            }
        }

        return sol;

    }
};
/*
b)
class Solution {
public:
    stack <int> st; //in st vom adauga cursurile dupa ce au fost parcurse toate cursurile de dupa ele
    bool ok=1; //marcheaza daca putem construi solutie
    vector<int> v; //vectorul cursurilor ce depind circular unele de altele
    int start; //nodul de la care porneste ciclul

    vector<int>  dfs(int nod, vector<int> &viz, vector<int> l[])
    {
        v.push_back(nod); //adaug nodurile din parcurgere in v, pana dau de un ciclu
        if(ok==1)
        {
            viz[nod]=-1; //marcam cu -1 cand incepem parcurgerea de la cursul 'nod'
            for(int i=0; i<l[nod].size(); i++)
            {
                if(viz[l[nod][i]]==0)
                    dfs(l[nod][i],viz, l);
                if(viz[l[nod][i]]==-1) //daca cursul apartine deja parcurgerii, atunci a fost facut inainte de cursul 'nod' => contradictie
                {
                    ok=0;
                    v.push_back(l[nod][i]); //adaug ultimul nod din ciclu in vectorul v si ies din functie
                    start=l[nod][i]; //nodul de final e si de inceput
                    return v;
                }

            }
            st.push(nod); //punem cursul in stiva dupa terminarea dfs-ului pt el
            viz[nod]=1; //marcam cu 1 cand am terminat parcurgerea ce incepe cu cursul 'nod'
        }
        return v;

    }


    vector <int> findOrder(int numCourses, vector<vector<int>>& prerequisites)
    {
        vector<int> l[numCourses+2], viz(numCourses+2), sol;
        for(int i=0; i<numCourses; i++)
            viz[i]=0;
        for(int i=0; i<prerequisites.size(); i++)
            l[prerequisites[i][1]].push_back(prerequisites[i][0]); //creare liste adiacenta

        vector <int> sol1;
        for(int i=0;i<numCourses;i++)
        {
            if(viz[i]==0)
                sol=dfs(i, viz, l);
        }

        if(ok==0)
        {
            //Gasesc ciclul care incepe cu start in vectorul sol si il pun invers in sol1
            int i=sol.size()-1;
            sol1.push_back(sol[i]);
            i--;

            while(sol[i]!=start)
            {
                sol1.push_back(sol[i]);
                i--;

            }
            sol1.push_back(sol[i]);
        }

        reverse(sol1.begin(), sol1.end());
        return sol1;
    }
};
*/

#include <iostream>
#include <fstream>
#include <deque>
#define nmax 100000000

using namespace std;

ifstream in("padure.in");
ofstream out("padure.out");

int n, m, pl, pc, cl, cc;
int tip[1005][1005];
int rez[1005][1005]; //in rez pastrez la fiecare pozitie nr de diamante folosite
int di[4] = {0, 0, -1, 1};
int dj[4] = {-1, 1, 0 ,0};

int main()
{
    in>>n>>m>>pl>>pc>>cl>>cc;

    for(int i=1; i<=n; i++)
        {
        for(int j=1; j<=m; j++)
        {
            in>>tip[i][j];
            rez[i][j]=nmax; //initializez cu un nr mare ca sa pot face comparatia intre nr de diamante
        }
    }

    deque <pair<int,int>> q;

    q.push_front(make_pair(pl, pc));//adaug in coada pozitia de start
    rez[pl][pc]=0;
    while(!q.empty())
    {
        int i=q.front().first;
        int j=q.front().second; // determin elementul de la inceput
        q.pop_front();
        for(int k=0; k<4; k++)//parcurg toti vecinii elementului
        {
            int iv=i+di[k];
            int jv=j+dj[k];
            if(iv>=1 && iv<=n && jv>=1 && jv<=m)
                {
                if(tip[iv][jv]!=tip[i][j]) //daca vecinul are copaci de alt tip
                {
                    if(rez[iv][jv]>rez[i][j]+1)//si daca nr de diamante din vecin e mai mare decat nr de diamante curente+1
                    {
                        rez[iv][jv]=rez[i][j]+1;//adaug un diamant in plus la cele deja puse
                        if(iv!=cl || jv!=cc)
                            q.push_back(make_pair(iv, jv));//daca nu am ajuns la castel, pun vecinul in coada
                    }
                }
                //daca vecinul are acc tip de copaci
                else
                {
                    if(rez[iv][jv]>rez[i][j])
                    {
                        rez[iv][jv]=rez[i][j];//nu schimb nr de diamante
                        if(iv!=cl || jv!=cc)
                            q.push_front(make_pair(iv, jv));
                    }
                }
            }
        }
    }

    out<<rez[cl][cc];

    return 0;
}

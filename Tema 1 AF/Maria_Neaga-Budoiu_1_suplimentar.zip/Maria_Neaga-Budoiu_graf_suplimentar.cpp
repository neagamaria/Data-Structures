#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <queue>

using namespace std;

ifstream in("graf.in");
ofstream out("graf.out");

int n, m, x, y;
int nr; //nr noduri comune
vector<vector<int>> l;
vector<int> comun; //vector noduri comune

vector<int> bfs(int nod) //parcurgere bfs cu returnarea vectorului de distante pana la nodul de inceput
{
    vector<int> d(n, 0);
    vector<bool> viz(n, 0);
    int coada[100000];

    viz[nod]=d[nod]=1;
    int inc, sf;
    inc=sf=1;
    coada[inc]=nod;
    while(inc<=sf)
    {
        for(int i=0; i<l[coada[inc]].size(); i++)
        {
            int x=l[coada[inc]][i];
            if(viz[x]==0)
            {
                viz[x]=1;
                coada[++sf]=x;
                d[x]=d[coada[inc]]+1;
            }
        }
        inc++;
    }


    return d;
}

int main ()
{
    int a, b;
    in>>n>>m>>x>>y;

    l.resize(n+1);
    for (int i=1; i<=m; i++)
    {
        in>>a>>b;
        l[a].push_back(b);
        l[b].push_back(a);
    }

    vector<int> dx=bfs(x);
    vector<int> dy=bfs(y);

    vector<int> cnt(n);

    for(int i=1; i<=n; i++)
        if (dx[i]+dy[i]==dx[y]+1) //nodul e valid, il numar
            cnt[dx[i]]++;
        else dx[i]=0; //nodul nu face parte din lant optim

    for(int i=1; i<=n; i++)
        if(cnt[dx[i]]==1) //daca e singurul nod pe nivel, e nod comun
        {
            nr++;
            comun.push_back(i);
        }

    out<<nr<<endl;
    sort(comun.begin(), comun.end()); //sortare noduri pentru afisare
    for(int i=0; i<comun.size(); i++)
        out<<comun[i]<<" ";

    return 0;
}
